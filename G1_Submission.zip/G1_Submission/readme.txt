Hello and Welcome to Group 1's Lab 4 Submission

Dani Brown
Austin Padilla
Giovanni Cornejo

The effort in this Lab was split equally.  Dani Brown and Austin Padilla
wired and programmed the Pi while Giovanni wrote code for the microservices.
The IoT Application was written by Dani with troubleshooting assistance
and final fit performed by Austin.

We created four services.  They are:

A service that triggers a buzzer for a user specified length of time.
A service that tracks whether a button is pressed.
A service that blinks an LED for a specified length of time.
A service that determines the tilt of the smart device.
